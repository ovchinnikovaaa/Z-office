package com.example.zoffice;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.support.annotation.NonNull;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import androidx.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    ImageView imgMap;
    ImageView imgDial;
    ImageView imgMail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    imgMap = findViewById(R.id.img_map);
    imgDial = findViewById(R.id.img_dial);
    imgMail = findViewById(R.id.img_mail);

    BottomNavigationView bottomNavigationView = (BottomNavigationView)
            findViewById(R.id.bottom_navigation);

        bottomNavigationView.setOnNavigationItemSelectedListener(
                new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.action_map:
                    imgMap.setVisibility(View.VISIBLE);
                    imgDial.setVisibility(View.GONE);
                    imgMail.setVisibility(View.GONE);
                    break;
                case R.id.action_dial:
                    imgMap.setVisibility(View.GONE);
                    imgDial.setVisibility(View.VISIBLE);
                    imgMail.setVisibility(View.GONE);
                    break;
                case R.id.action_mail:
                    imgMap.setVisibility(View.GONE);
                    imgDial.setVisibility(View.GONE);
                    imgMail.setVisibility(View.VISIBLE);
                    break;
            }
            return false;
        }
    });
}
}